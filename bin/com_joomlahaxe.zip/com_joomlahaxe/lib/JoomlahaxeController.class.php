<?php

class JoomlahaxeController extends JControllerLegacy {
	public function __construct($config) { if(!php_Boot::$skip_constructor) {
		jimport('joomla.application.component.controller');
		$config1 = null;
		$config1 = Array("[\"name\":\"Joomlahaxe\"]");
		defined('_JEXEC') or die();
		parent::__construct($config1);
	}}
	public function display($cachable = null, $urlparams = null) {
		$input = JFactory::getApplication()->input;
		$input->set("view", $input->getCmd("view", "Joomlahaxe"));
		parent::display($cachable,null);
		return null;
	}
	static function main() {
		new JoomlahaxeController(null);
	}
	static $__properties__ = array("get_input" => "get_input","get_taskMap" => "get_taskMap","get_task" => "get_task","get_redirecturl" => "get_redirecturl","get_paths" => "get_paths","get_model_prefix" => "get_model_prefix","get_name" => "get_name","get_methods" => "get_methods","get_messageType" => "get_messageType","get_message" => "get_message","get_doTask" => "get_doTask","get_default_view" => "get_default_view","get_basePath" => "get_basePath");
	function __toString() { return 'JoomlahaxeController'; }
}
