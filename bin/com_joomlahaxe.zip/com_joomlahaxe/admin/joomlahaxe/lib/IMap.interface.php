<?php

interface IMap {
}
