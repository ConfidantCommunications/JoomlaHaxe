<?php

_hx_register_type(new _hx_class('GeneratedJController', 'GeneratedJController', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../GeneratedJController.class.php'));
_hx_register_type(new _hx_class('haxe_ds_IntMap', 'haxe.ds.IntMap', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../haxe/ds/IntMap.class.php'));
_hx_register_type(new _hx_class('haxe_ds_StringMap', 'haxe.ds.StringMap', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../haxe/ds/StringMap.class.php'));
_hx_register_type(new _hx_class('haxe_io_Eof', 'haxe.io.Eof', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../haxe/io/Eof.class.php'));
_hx_register_type(new _hx_enum('haxe_macro_Binop', 'haxe.macro.Binop', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../haxe/macro/Binop.enum.php'));
_hx_register_type(new _hx_enum('haxe_macro_ComplexType', 'haxe.macro.ComplexType', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../haxe/macro/ComplexType.enum.php'));
_hx_register_type(new _hx_enum('haxe_macro_Constant', 'haxe.macro.Constant', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../haxe/macro/Constant.enum.php'));
_hx_register_type(new _hx_enum('haxe_macro_ExprDef', 'haxe.macro.ExprDef', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../haxe/macro/ExprDef.enum.php'));
_hx_register_type(new _hx_enum('haxe_macro_TypeParam', 'haxe.macro.TypeParam', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../haxe/macro/TypeParam.enum.php'));
_hx_register_type(new _hx_enum('haxe_macro_Unop', 'haxe.macro.Unop', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../haxe/macro/Unop.enum.php'));
_hx_register_type(new _hx_class('HList', 'List', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../HList.class.php'));
_hx_register_type(new _hx_interface('IMap', 'IMap', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../IMap.interface.php'));
_hx_register_type(new _hx_class('JApplicationCms', 'JApplicationCms', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../JApplicationCms.class.php'));
_hx_register_type(new _hx_class('Main', 'Main', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../Main.class.php'));
_hx_register_type(new _hx_class('php_Boot', 'php.Boot', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../php/Boot.class.php'));
_hx_register_type(new _hx_class('php_Lib', 'php.Lib', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../php/Lib.class.php'));
_hx_register_type(new _hx_class('PHP', 'PHP', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../PHP.class.php'));
_hx_register_type(new _hx_class('Std', 'Std', '/Applications/MAMPold/htdocs_artworks/components/com_joomlahaxe/lib/php/../Std.class.php'));
