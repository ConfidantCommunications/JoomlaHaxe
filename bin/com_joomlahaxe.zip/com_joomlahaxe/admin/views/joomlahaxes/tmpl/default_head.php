<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
	<th width="5">
		<?php echo 'ID'; ?>
	</th>
	<th width="20">
		<input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" />
	</th>			
	<th>
		Name
	</th>				
	<th>
		Description
	</th>		
	<th>
		Enabled
	</th>
</tr>