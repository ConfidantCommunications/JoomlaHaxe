<?php

class JDatabaseQueryMysqli {
	public function __construct() {
		if(!php_Boot::$skip_constructor) {
		$GLOBALS['%s']->push("JDatabaseQueryMysqli::new");
		$__hx__spos = $GLOBALS['%s']->length;
		{
			$GLOBALS['%s']->pop();
			$this->__inst = new mysqli();
			return;
		}
		$GLOBALS['%s']->pop();
	}}
	public $__inst;
	public function get_offset() {
		$GLOBALS['%s']->push("JDatabaseQueryMysqli::get_offset");
		$__hx__spos = $GLOBALS['%s']->length;
		{
			$GLOBALS['%s']->pop();
			return $this->__inst->offset;
		}
		$GLOBALS['%s']->pop();
	}
	public function get_limit() {
		$GLOBALS['%s']->push("JDatabaseQueryMysqli::get_limit");
		$__hx__spos = $GLOBALS['%s']->length;
		{
			$GLOBALS['%s']->pop();
			return $this->__inst->limit;
		}
		$GLOBALS['%s']->pop();
	}
	public function processLimit($query = null, $limit = null, $offset = null) {
		$GLOBALS['%s']->push("JDatabaseQueryMysqli::processLimit");
		$__hx__spos = $GLOBALS['%s']->length;
		{
			$tmp = $this->__inst->processLimit($query, $limit, $offset);
			$GLOBALS['%s']->pop();
			return $tmp;
		}
		$GLOBALS['%s']->pop();
	}
	public function concatenate($values = null, $separator = null) {
		$GLOBALS['%s']->push("JDatabaseQueryMysqli::concatenate");
		$__hx__spos = $GLOBALS['%s']->length;
		{
			$tmp = $this->__inst->concatenate($values, $separator);
			$GLOBALS['%s']->pop();
			return $tmp;
		}
		$GLOBALS['%s']->pop();
	}
	public function setLimit($limit = null, $offset = null) {
		$GLOBALS['%s']->push("JDatabaseQueryMysqli::setLimit");
		$__hx__spos = $GLOBALS['%s']->length;
		{
			$tmp = $this->__inst->setLimit($limit, $offset);
			$GLOBALS['%s']->pop();
			return $tmp;
		}
		$GLOBALS['%s']->pop();
	}
	public function regexp($value = null) {
		$GLOBALS['%s']->push("JDatabaseQueryMysqli::regexp");
		$__hx__spos = $GLOBALS['%s']->length;
		{
			$tmp = $this->__inst->regexp($value);
			$GLOBALS['%s']->pop();
			return $tmp;
		}
		$GLOBALS['%s']->pop();
	}
	public function resolve($field) {
		$GLOBALS['%s']->push("JDatabaseQueryMysqli::resolve");
		$__hx__spos = $GLOBALS['%s']->length;
		{
			$tmp = $this->__inst->$field;
			$GLOBALS['%s']->pop();
			return $tmp;
		}
		$GLOBALS['%s']->pop();
	}
	public $__dynamics = array();
	public function __get($n) {
		if(isset($this->__dynamics[$n]))
			return $this->__dynamics[$n];
	}
	public function __set($n, $v) {
		$this->__dynamics[$n] = $v;
	}
	public function __call($n, $a) {
		if(isset($this->__dynamics[$n]) && is_callable($this->__dynamics[$n]))
			return call_user_func_array($this->__dynamics[$n], $a);
		if('toString' == $n)
			return $this->__toString();
		throw new HException("Unable to call <".$n.">");
	}
	static $__properties__ = array("get_limit" => "get_limit","get_offset" => "get_offset");
	function __toString() { return 'JDatabaseQueryMysqli'; }
}
require_once '/Applications/MAMPold/htdocs_artworks/libraries/joomla/database/query/mysqli.php';
