<?php

class Main {
	public function __construct(){}
	static function main() {
		php_Lib::println("Haxe is great!");
	}
	function __toString() { return 'Main'; }
}
