<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<h1>Works</h1>
<p>
<?php echo $this->msg;  ?>
</p>