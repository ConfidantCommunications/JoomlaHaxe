<?php

class GeneratedJController {
	public function __construct($JInputinput = null, $JApplicationBaseapp = null) {
		if(!php_Boot::$skip_constructor) {
		$this->__inst = new base($JInputinput, $JApplicationBaseapp);
		return;
	}}
	public $__inst;
	public function get_app() {
		return $this->__inst->app;
	}
	public function get_input() {
		return $this->__inst->input;
	}
	public function getApplication() {
		return $this->__inst->getApplication();
	}
	public function getInput() {
		return $this->__inst->getInput();
	}
	public function serialize() {
		return $this->__inst->serialize();
	}
	public function unserialize($input = null) {
		return $this->__inst->unserialize($input);
	}
	public function loadApplication() {
		return $this->__inst->loadApplication();
	}
	public function loadInput() {
		return $this->__inst->loadInput();
	}
	public function resolve($field) {
		return $this->__inst->$field;
	}
	public $__dynamics = array();
	public function __get($n) {
		if(isset($this->__dynamics[$n]))
			return $this->__dynamics[$n];
	}
	public function __set($n, $v) {
		$this->__dynamics[$n] = $v;
	}
	public function __call($n, $a) {
		if(isset($this->__dynamics[$n]) && is_callable($this->__dynamics[$n]))
			return call_user_func_array($this->__dynamics[$n], $a);
		if('toString' == $n)
			return $this->__toString();
		throw new HException("Unable to call <".$n.">");
	}
	static $__properties__ = array("get_input" => "get_input","get_app" => "get_app");
	function __toString() { return 'GeneratedJController'; }
}
require_once '/Applications/MAMPold/htdocs_artworks/libraries/joomla/controller/base.php';
