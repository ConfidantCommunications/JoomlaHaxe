<?php

interface sys_db_ResultSet {
	function next();
}
